from datetime import datetime
now = datetime.now()
date = now.strftime("%d/%m/%Y")
msg = "Message received on " + date
def handler(event, context):
            response = {
              'isBase64Encoded': False,
              'statusCode': 200,
              'headers': {},
              'multiValueHeaders': {},
              'body': msg,
            }
            return response